﻿using System;
using Microsoft.EntityFrameworkCore;
using SocialMedia.Core.Entities;
using SocialMedia.Infrastructure.Data.Configurations;

namespace SocialMedia.Infrastructure.Data
{

public partial class SocialMediaContext : DbContext
    {
        public SocialMediaContext()
        {
        }
    
        public SocialMediaContext(DbContextOptions<SocialMediaContext> options)
            : base(options)
        {
        }
    
        public virtual DbSet<Comment> Comment { get; set; }
        public virtual DbSet<Post> Post { get; set; }
        public virtual DbSet<User> User { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CommentConfiguration());
            modelBuilder.ApplyConfiguration(new PostConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Comment>()
                    .HasOne(c => c.Post)
                    .WithMany(p => p.Comment)
                    .HasForeignKey(c => c.PostId)
                    .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Comment>()
                    .HasOne(c => c.Post)
                    .WithMany(p => p.Comment)
                    .HasForeignKey(c => c.PostId)
                    .OnDelete(DeleteBehavior.SetNull);

            
            modelBuilder.Entity<Post>()
                .HasKey(p => p.Id);

            modelBuilder.Entity<Post>()
                .Property(p => p.Id)
                .HasColumnName("PostId");

            modelBuilder.Entity<User>()
                .HasKey(e => e.Id);

            modelBuilder.Entity<User>()
                .Property(e => e.Id)
                .HasColumnName("UserId");

        }
    }
}
