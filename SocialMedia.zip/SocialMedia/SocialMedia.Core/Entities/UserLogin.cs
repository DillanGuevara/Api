﻿namespace SocialMedia.Core.Entities
{
    public class UserLogin
    {
        public string User { get; set; }
        public string Password { get; set; }
    }
}
