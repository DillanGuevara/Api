﻿namespace SocialMedia.Core.CustomEntities
{
    public class PaginationOptions
    {
        public int DefaultPageSize { get; set; }

        public int DefaultPageNumber { get; set; }
    }
}
