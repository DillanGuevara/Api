using System;
using Xunit;

namespace SocialMediaIntegrationTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
