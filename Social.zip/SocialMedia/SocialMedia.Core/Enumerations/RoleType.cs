﻿namespace SocialMedia.Core.Enumerations
{
    public enum RoleType
    {
        Administrator,
        Consumer
    }
}
